// src/pages/Messages.jsx
import React, { useState } from 'react';

const Messages = () => {
  const [conversations, setConversations] = useState([
    {
      id: 1,
      user: {
        name: 'Mbiys Dave',
        handle: 'mbiysdave',
        avatar: 'https://placeholder.com/50',
      },
      lastMessage: 'Hey, how are you?',
      timestamp: '2h',
      unread: true,
    },
    // Add more conversations
  ]);

  const [selectedConversation, setSelectedConversation] = useState(null);
  const [newMessage, setNewMessage] = useState('');

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (newMessage.trim()) {
      // Add message sending logic here
      setNewMessage('');
    }
  };

  return (
    <div className="messages-page">
      <div className="messages-sidebar">
        <header className="messages-header">
          <h2>Messages</h2>
          <button className="new-message-btn">
            <span>✉️</span>
          </button>
        </header>

        <div className="conversations-list">
          {conversations.map(conv => (
            <div 
              key={conv.id} 
              className={`conversation-item ${conv.unread ? 'unread' : ''}`}
              onClick={() => setSelectedConversation(conv)}
            >
              <img 
                src={conv.user.avatar} 
                alt={conv.user.name} 
                className="conversation-avatar" 
              />
              <div className="conversation-content">
                <div className="conversation-header">
                  <span className="conversation-name">{conv.user.name}</span>
                  <span className="conversation-handle">@{conv.user.handle}</span>
                  <span className="conversation-time">{conv.timestamp}</span>
                </div>
                <p className="conversation-preview">{conv.lastMessage}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="messages-main">
        {selectedConversation ? (
          <>
            <header className="chat-header">
              <div className="chat-user-info">
                <img 
                  src={selectedConversation.user.avatar} 
                  alt={selectedConversation.user.name} 
                  className="chat-avatar" 
                />
                <div>
                  <h3>{selectedConversation.user.name}</h3>
                  <span>@{selectedConversation.user.handle}</span>
                </div>
              </div>
            </header>

            <div className="chat-messages">
              {/* Messages will be displayed here */}
            </div>

            <form className="message-form" onSubmit={handleSendMessage}>
              <input
                type="text"
                placeholder="Start a new message"
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
              />
              <button type="submit">Send</button>
            </form>
          </>
        ) : (
          <div className="select-conversation">
            <h3>Select a message</h3>
            <p>Choose from your existing conversations or start a new one.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Messages;
