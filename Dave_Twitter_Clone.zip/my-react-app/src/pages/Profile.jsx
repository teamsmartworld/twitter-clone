// src/pages/Profile.jsx
import React, { useState } from 'react';

const Profile = () => {
  const [activeTab, setActiveTab] = useState('tweets');
  const [userProfile] = useState({
    name: 'Mbiys Dave',
    handle: 'mbiysdave',
    avatar: 'https://placeholder.com/150',
    coverImage: 'https://placeholder.com/600x200',
    bio: 'Software Developer | React Enthusiast | Coffee Lover ☕',
    location: '📍 Nassjo - Sweden, CA',
    website: 'https://mbiysdave.dev',
    joinDate: 'Joined January 2020',
    following: 234,
    followers: 567,
  });

  const [tweets] = useState([
    {
      id: 1,
      content: 'Just launched my new project! #coding #react',
      timestamp: '2h',
      likes: 45,
      retweets: 12,
      replies: 8,
    },
    // Add more tweets
  ]);

  const tabs = [
    { id: 'tweets', label: 'Tweets' },
    { id: 'replies', label: 'Replies' },
    { id: 'media', label: 'Media' },
    { id: 'likes', label: 'Likes' },
  ];

  return (
    <div className="profile-page">
      <header className="profile-header">
        <div className="cover-image">
          <img src={userProfile.coverImage} alt="Cover" />
        </div>
        
        <div className="profile-info-container">
          <div className="profile-avatar-container">
            <img 
              src={userProfile.avatar} 
              alt={userProfile.name} 
              className="profile-avatar"
            />
          </div>
          
          <button className="edit-profile-button">
            Edit Profile
          </button>
          
          <div className="profile-info">
            <h2 className="profile-name">{userProfile.name}</h2>
            <span className="profile-handle">@{userProfile.handle}</span>
            
            <p className="profile-bio">{userProfile.bio}</p>
            
            <div className="profile-metadata">
              <span className="profile-location">{userProfile.location}</span>
              <span className="profile-website">
                🔗 {userProfile.website}
              </span>
              <span className="profile-join-date">{userProfile.joinDate}</span>
            </div>
            
            <div className="profile-stats">
              <span className="following">
                <strong>{userProfile.following}</strong> Following
              </span>
              <span className="followers">
                <strong>{userProfile.followers}</strong> Followers
              </span>
            </div>
          </div>
        </div>

        <nav className="profile-nav">
          {tabs.map(tab => (
            <button
              key={tab.id}
              className={`profile-nav-item ${activeTab === tab.id ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.id)}
            >
              {tab.label}
            </button>
          ))}
        </nav>
      </header>

      <div className="profile-content">
        {activeTab === 'tweets' && (
          <div className="tweets-container">
            {tweets.map(tweet => (
              <div key={tweet.id} className="tweet">
                <p className="tweet-content">{tweet.content}</p>
                <div className="tweet-metadata">
                  <span>{tweet.timestamp}</span>
                </div>
                <div className="tweet-stats">
                  <span>🗨️ {tweet.replies}</span>
                  <span>🔄 {tweet.retweets}</span>
                  <span>❤️ {tweet.likes}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Profile;
