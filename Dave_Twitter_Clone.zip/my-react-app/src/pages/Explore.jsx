// src/pages/Explore.jsx
import React, { useState } from 'react';
import SearchBar from '../components/SearchBar';

const Explore = () => {
  const [trendingTopics] = useState([
    {
      id: 1,
      category: 'Trending in Technology',
      title: '#JavaScript',
      tweetCount: '125.4K tweets',
    },
    {
      id: 2,
      category: 'Sports · Trending',
      title: '#WorldCup2026',
      tweetCount: '85.2K tweets',
    },
    // Add more trending topics
  ]);

  const [newsStories] = useState([
    {
      id: 1,
      title: 'Latest Tech News',
      image: 'https://placeholder.com/300x200',
      category: 'Technology',
      time: '2 hours ago',
    },
    // Add more news stories
  ]);

  return (
    <div className="explore-page">
      <header className="explore-header">
        <SearchBar />
      </header>

      <div className="explore-content">
        <section className="trending-section">
          <h2>Trends for you</h2>
          {trendingTopics.map(topic => (
            <div key={topic.id} className="trending-item">
              <div className="trending-item-category">{topic.category}</div>
              <div className="trending-item-title">{topic.title}</div>
              <div className="trending-item-tweets">{topic.tweetCount}</div>
            </div>
          ))}
        </section>

        <section className="news-section">
          <h2>What's happening</h2>
          {newsStories.map(story => (
            <div key={story.id} className="news-item">
              <div className="news-item-content">
                <div className="news-item-meta">
                  <span className="news-item-category">{story.category}</span>
                  <span className="news-item-time">{story.time}</span>
                </div>
                <h3 className="news-item-title">{story.title}</h3>
              </div>
              <img src={story.image} alt={story.title} className="news-item-image" />
            </div>
          ))}
        </section>
      </div>
    </div>
  );
};

export default Explore;
