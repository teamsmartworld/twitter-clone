// src/pages/Notifications.jsx
import React, { useState } from 'react';

const Notifications = () => {
  const [activeTab, setActiveTab] = useState('all');
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      type: 'like',
      user: {
        name: 'Mbiys Dave',
        handle: 'mbiysdave',
        avatar: 'https://placeholder.com/50',
      },
      content: 'liked your tweet',
      timestamp: '2h',
      tweetPreview: 'This is the tweet that was liked...',
    },
    {
      id: 2,
      type: 'retweet',
      user: {
        name: 'Jane Smith',
        handle: 'janesmith',
        avatar: 'https://placeholder.com/50',
      },
      content: 'retweeted your tweet',
      timestamp: '4h',
      tweetPreview: 'This is the tweet that was retweeted...',
    },
    // Add more notifications
  ]);

  const filterNotifications = (type) => {
    if (type === 'all') return notifications;
    return notifications.filter(notif => notif.type === type);
  };

  const getNotificationIcon = (type) => {
    switch (type) {
      case 'like': return '❤️';
      case 'retweet': return '🔄';
      case 'mention': return '@';
      case 'follow': return '👤';
      default: return '📢';
    }
  };

  return (
    <div className="notifications-page">
      <header className="notifications-header">
        <h2>Notifications</h2>
        <div className="notifications-tabs">
          <button 
            className={`tab ${activeTab === 'all' ? 'active' : ''}`}
            onClick={() => setActiveTab('all')}
          >
            All
          </button>
          <button 
            className={`tab ${activeTab === 'mentions' ? 'active' : ''}`}
            onClick={() => setActiveTab('mentions')}
          >
            Mentions
          </button>
        </div>
      </header>

      <div className="notifications-list">
        {filterNotifications(activeTab).map(notification => (
          <div key={notification.id} className="notification-item">
            <span className="notification-icon">
              {getNotificationIcon(notification.type)}
            </span>
            <img 
              src={notification.user.avatar} 
              alt={notification.user.name} 
              className="notification-avatar" 
            />
            <div className="notification-content">
              <div className="notification-header">
                <span className="notification-name">
                  {notification.user.name}
                </span>
                <span className="notification-handle">
                  @{notification.user.handle}
                </span>
                <span className="notification-time">
                  {notification.timestamp}
                </span>
              </div>
              <p className="notification-text">
                {notification.content}
              </p>
              {notification.tweetPreview && (
                <div className="notification-preview">
                  {notification.tweetPreview}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Notifications;
