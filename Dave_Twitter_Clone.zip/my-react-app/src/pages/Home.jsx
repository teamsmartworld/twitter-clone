// src/pages/Home.jsx
import React, { useState } from 'react';
import TweetForm from '../components/TweetForm';
import TweetList from '../components/TweetList';

const Home = () => {
  const [tweets, setTweets] = useState([
    {
      id: 1,
      username: 'Mbiys Dave',
      handle: 'mbiysdave',
      userAvatar: 'https://placeholder.com/150',
      content: 'This is my first tweet! #excited',
      timestamp: new Date().toISOString(),
      likes: 5,
      retweets: 2,
      comments: 1,
      isLiked: false,
      isRetweeted: false
    },
    // Add more sample tweets here
  ]);

  const handleNewTweet = (tweetContent) => {
    const newTweet = {
      id: Date.now(),
      username: 'Current User',
      handle: 'currentuser',
      userAvatar: 'https://placeholder.com/150',
      content: tweetContent.content,
      timestamp: new Date().toISOString(),
      likes: 0,
      retweets: 0,
      comments: 0,
      isLiked: false,
      isRetweeted: false
    };

    setTweets([newTweet, ...tweets]);
  };

  const handleRetweet = (tweetId, isRetweeting) => {
    if (isRetweeting) {
      const originalTweet = tweets.find(t => t.id === tweetId);
      const retweet = {
        ...originalTweet,
        id: Date.now(),
        isRetweet: true,
        retweetedBy: 'Current User',
        timestamp: new Date().toISOString(),
        originalTweetId: tweetId
      };
      setTweets([retweet, ...tweets]);
    }
    
    setTweets(tweets.map(tweet => 
      tweet.id === tweetId 
        ? { ...tweet, retweets: isRetweeting ? tweet.retweets + 1 : tweet.retweets - 1 }
        : tweet
    ));
  };

  const handleLike = (tweetId, isLiking) => {
    setTweets(tweets.map(tweet =>
      tweet.id === tweetId
        ? { ...tweet, likes: isLiking ? tweet.likes + 1 : tweet.likes - 1, isLiked: isLiking }
        : tweet
    ));
  };

  return (
    <main className="home">
      <header className="home-header">
        <h1>Home</h1>
      </header>
      <TweetForm onTweetSubmit={handleNewTweet} />
      <TweetList 
        tweets={tweets}
        onRetweet={handleRetweet}
        onLike={handleLike}
      />
    </main>
  );
};

export default Home;
