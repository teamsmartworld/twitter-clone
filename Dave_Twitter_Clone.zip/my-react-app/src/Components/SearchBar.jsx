// src/components/SearchBar.jsx
import React, { useState } from 'react';

const SearchBar = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  const handleSearch = (query) => {
    setSearchQuery(query);
    // Mock search results - replace with actual API call
    if (query.trim()) {
      const mockResults = [
        {
          id: 1,
          type: 'user',
          name: 'John Doe',
          handle: 'johndoe',
          avatar: 'https://placeholder.com/50',
        },
        {
          id: 2,
          type: 'hashtag',
          text: '#coding',
          tweetCount: '12.5K',
        },
        {
          id: 3,
          type: 'tweet',
          user: 'Jane Smith',
          handle: 'janesmith',
          content: 'This is a sample tweet containing "' + query + '"',
        },
      ];
      setSearchResults(mockResults);
    } else {
      setSearchResults([]);
    }
  };

  return (
    <div className="search-container">
      <div className="search-input-wrapper">
        <span className="search-icon">🔍</span>
        <input
          type="text"
          className="search-input"
          placeholder="Search Twitter"
          value={searchQuery}
          onChange={(e) => handleSearch(e.target.value)}
          onFocus={() => setIsSearchFocused(true)}
          onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)}
        />
        {searchQuery && (
          <button 
            className="clear-search"
            onClick={() => {
              setSearchQuery('');
              setSearchResults([]);
            }}
          >
            ✕
          </button>
        )}
      </div>

      {isSearchFocused && searchResults.length > 0 && (
        <div className="search-results">
          {searchResults.map((result) => (
            <div key={result.id} className="search-result-item">
              {result.type === 'user' && (
                <div className="user-result">
                  <img src={result.avatar} alt={result.name} className="result-avatar" />
                  <div className="result-user-info">
                    <span className="result-name">{result.name}</span>
                    <span className="result-handle">@{result.handle}</span>
                  </div>
                </div>
              )}
              
              {result.type === 'hashtag' && (
                <div className="hashtag-result">
                  <span className="result-icon">#</span>
                  <div className="result-hashtag-info">
                    <span className="result-text">{result.text}</span>
                    <span className="result-tweet-count">{result.tweetCount} Tweets</span>
                  </div>
                </div>
              )}
              
              {result.type === 'tweet' && (
                <div className="tweet-result">
                  <span className="result-icon">📝</span>
                  <div className="result-tweet-info">
                    <span className="result-user">{result.user}</span>
                    <span className="result-content">{result.content}</span>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default SearchBar;
