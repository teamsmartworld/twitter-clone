// src/components/TweetList.jsx
import React from 'react';
import Tweet from './Tweet';

const TweetList = ({ tweets, onRetweet, onLike }) => {
  if (!tweets || tweets.length === 0) {
    return (
      <div className="no-tweets">
        <p>No tweets yet. Be the first to tweet!</p>
      </div>
    );
  }

  return (
    <div className="tweet-list">
      {tweets.map(tweet => (
        <Tweet 
          key={tweet.id} 
          tweet={tweet}
          onRetweet={onRetweet}
          onLike={onLike}
        />
      ))}
    </div>
  );
};

export default TweetList;
