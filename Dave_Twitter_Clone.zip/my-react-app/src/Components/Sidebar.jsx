// src/components/Sidebar.jsx
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';

const Sidebar = ({ isDarkMode }) => {
  const location = useLocation();
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);

  const menuItems = [
    { icon: '🏠', label: 'Home', path: '/' },
    { icon: '🔍', label: 'Explore', path: '/explore' },
    { icon: '🔔', label: 'Notifications', path: '/notifications' },
    { icon: '✉️', label: 'Messages', path: '/messages' },
    { icon: '👤', label: 'Profile', path: '/profile' },
  ];

  return (
    <div className={`sidebar ${isDarkMode ? 'dark-mode' : ''}`}>
      <div className="logo">
        <Link to="/" className="logo-icon">🐦</Link>
      </div>
      
      <nav className="sidebar-menu">
        {menuItems.map(item => (
          <Link
            key={item.label}
            to={item.path}
            className={`menu-item ${location.pathname === item.path ? 'active' : ''}`}
          >
            <span className="menu-icon">{item.icon}</span>
            <span className="menu-label">{item.label}</span>
          </Link>
        ))}
      </nav>

      <button className="tweet-button">
        Tweet
      </button>

      <div 
        className="user-profile"
        onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
      >
        <img 
          src="https://placeholder.com/50" 
          alt="User avatar" 
          className="profile-avatar"
        />
        <div className="profile-info">
          <span className="profile-name">Mbiys Dave</span>
          <span className="profile-handle">@mbiysdave</span>
        </div>
        {isProfileMenuOpen && (
          <div className="profile-dropdown">
            <Link to="/profile" className="dropdown-item">Profile</Link>
            <div className="dropdown-item">Settings</div>
            <div className="dropdown-item">Log out</div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Sidebar;
