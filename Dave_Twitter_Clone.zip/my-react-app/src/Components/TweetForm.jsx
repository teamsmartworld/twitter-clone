// src/components/TweetForm.jsx
import React, { useState } from 'react';

const TweetForm = ({ onTweetSubmit }) => {
  const [tweetContent, setTweetContent] = useState('');
  
  const handleSubmit = (e) => {
    e.preventDefault();
    if (tweetContent.trim()) {
      onTweetSubmit({
        content: tweetContent,
        timestamp: new Date().toISOString(),
      });
      setTweetContent('');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="tweet-form">
      <textarea
        value={tweetContent}
        onChange={(e) => setTweetContent(e.target.value)}
        placeholder="What's happening?"
        maxLength={280}
      />
      <div className="tweet-form-footer">
        <span>{280 - tweetContent.length} characters remaining</span>
        <button type="submit">Tweet</button>
      </div>
    </form>
  );
};

export default TweetForm;
