// src/components/Tweet.jsx
import React, { useState } from 'react';

const Tweet = ({ tweet, onRetweet, onLike }) => {
  const [isRetweeted, setIsRetweeted] = useState(tweet.isRetweeted);
  const [isLiked, setIsLiked] = useState(tweet.isLiked);
  const [likesCount, setLikesCount] = useState(tweet.likes || 0);
  const [retweetCount, setRetweetCount] = useState(tweet.retweets || 0);

  const handleLike = () => {
    setIsLiked(!isLiked);
    setLikesCount(prev => isLiked ? prev - 1 : prev + 1);
    if (onLike) onLike(tweet.id, !isLiked);
  };

  const handleRetweet = () => {
    setIsRetweeted(!isRetweeted);
    setRetweetCount(prev => isRetweeted ? prev - 1 : prev + 1);
    if (onRetweet) onRetweet(tweet.id, !isRetweeted);
  };

  const formatDate = (dateString) => {
    const options = { hour: 'numeric', minute: 'numeric', hour12: true };
    return new Date(dateString).toLocaleString('en-US', options);
  };

  return (
    <div className="tweet">
      {tweet.isRetweet && (
        <div className="retweet-header">
          <span className="retweet-icon">🔄</span>
          <span>{tweet.retweetedBy} Retweeted</span>
        </div>
      )}
      <div className="tweet-content">
        <img 
          src={tweet.userAvatar || 'https://placeholder.com/150'} 
          alt="avatar" 
          className="tweet-avatar"
        />
        <div className="tweet-body">
          <div className="tweet-header">
            <span className="tweet-name">{tweet.username}</span>
            <span className="tweet-handle">@{tweet.handle}</span>
            <span className="tweet-time">· {formatDate(tweet.timestamp)}</span>
          </div>
          <p className="tweet-text">{tweet.content}</p>
          {tweet.image && (
            <img src={tweet.image} alt="Tweet media" className="tweet-image" />
          )}
          <div className="tweet-actions">
            <button className="tweet-action-btn comment">
              <span className="action-icon">💬</span>
              <span className="action-count">{tweet.comments || 0}</span>
            </button>
            <button 
              className={`tweet-action-btn retweet ${isRetweeted ? 'active' : ''}`}
              onClick={handleRetweet}
            >
              <span className="action-icon">🔄</span>
              <span className="action-count">{retweetCount}</span>
            </button>
            <button 
              className={`tweet-action-btn like ${isLiked ? 'active' : ''}`}
              onClick={handleLike}
            >
              <span className="action-icon">{isLiked ? '❤️' : '🤍'}</span>
              <span className="action-count">{likesCount}</span>
            </button>
            <button className="tweet-action-btn share">
              <span className="action-icon">📤</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Tweet;
